package com.msd.product.dto;

import com.msd.product.model.Product;

import lombok.Data;

@Data
public class ProductDto {

	private Product product;
	
	
}
